//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FileCpEx.rc
//
#define IDC_BTN_COPY                    2
#define IDD_FILECPEX_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_DLG_ERR                     130
#define IDD_DLG_PROGRESS                131
#define IDC_TXT_FROM                    1000
#define IDC_BTN_FROMBRW                 1001
#define IDC_TXT_TO                      1002
#define IDC_BTN_TOBRW                   1003
#define IDC_TXT_START                   1005
#define IDC_TXT_END                     1006
#define IDC_CK_DLG                      1007
#define IDC_CK_NULL                     1008
#define IDC_CMB_BUFSIZ                  1009
#define IDC_CK_FILEEND                  1010
#define IDC_TXT_RETRY                   1011
#define IDC_STXT_MES                    1011
#define IDC_TXT_SKIP                    1012
#define IDC_RADIO_SEL                   1012
#define IDC_STXT_TOTALSIZ               1012
#define IDC_RADIO_SEL2                  1013
#define IDC_STXT_CURSIZ                 1013
#define IDC_TXT_ERRSKIP                 1014
#define IDC_CK_SAMESEL                  1015
#define IDC_TXT_MOREERR                 1016
#define IDC_BTN_STOP                    1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
